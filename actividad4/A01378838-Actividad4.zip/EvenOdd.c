#include <stdio.h>

void main(){
    int n;
    scanf("%d",&n);
    if(n%2==0){
        printf("even\n");
    }else{
        printf("odd\n");
    }
}